<?php
namespace App\Services;

use App\Http\Controllers\API\BaseApiController;


class BrandRegisterService extends BaseApiController
{
    protected $request;
    protected $response;

    function __construct()
    {
        
    }

}

